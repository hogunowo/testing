const Discord = require('discord.js');
const { ask, colors, bot, getMs, errorEmbed } = require('../util/functions')
const Enmap = require('enmap');
const config = require('../util/config')

const welcome = require('../database/welcome')
const mutedRole = require('../database/mutedrole')

module.exports = {
    name: "set",
    aliases: ['config'],
    description: 'Setup welcome messages `!set welcome #channel` or the muted role `!set muted @role`',
    perms: 'MANAGE_CHANNELS',
    run: async (message, args, client, player) => {
        if (!args[1] || args[1].toLowerCase() != 'welcome') {
            if (!args[1] || args[1].toLowerCase() != 'muted') return;

            if (!message.mentions.roles.first() || message.mentions.roles.first().guild.id != message.guild.id) return errorEmbed({ m: message, e: "Invalid Role", d: "Please mention a valid role in this server for me to set as the muted role." });


            mutedRole.set(message.guild.id, message.mentions.roles.first().id);
            message.channel.send(`**Muted Role Set.** When users are muted they will be assigned with this role.`)
        } else {
            if (!message.mentions.channels.first() || message.mentions.channels.first().guild.id != message.guild.id) return errorEmbed({ m: message, e: "Invalid Channel", d: "Please mention a valid channel in this server for me to stream welcome messages to." });


            welcome.set(message.guild.id, message.mentions.channels.first().id);
            message.channel.send(`**Welcome Message Channel Set.** Welcome DMs will be streamed to <#${message.mentions.channels.first().id}>`)
        }



    }
}