const { ask, colors, bot, getMs, errorEmbed } = require('../util/functions')

module.exports = {
    name: "send",
    aliases: ['message', 'sendmessage', 'sendmsg'],
    description: 'Send a DM to a user.',
    perms: 'MANAGE_MESSAGES',
    run: async (message, args, client) => {
        const user = client.users.cache.get(args[1]) ? client.users.cache.get(args[1]) : message.mentions.users.first();
        if (!user) return errorEmbed({ m: message, e: "Invalid User", d: "Please provide a valid user id or mention a valid user in this server for me to send a DM to." });
        if (!args[2]) return errorEmbed({ m: message, e: "Invalid Message", d: `Please provide a message for me to send to ${user}.` });
        user.send(message.content.substring(args[0].length + args[1].length + 2)).then(m => {
            message.channel.send(`Your message has been sent to \`${user.tag}\``);

        }).catch(err => {
            return errorEmbed({ m: message, e: "Message Failed to send", d: "This user either has their DM's closed or has blocked the bot." });

        });


    }
}