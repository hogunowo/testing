
const Discord = require('discord.js');

module.exports = {
  name: "ping",
  aliases: ['latency'],
  description: 'Shows the bots ping.',
  perms: 'NONE',
  run: async (message, args, client) => {
        
    message.channel.send('Pinging...').then(sent => {
    sent.edit(`Roundtrip latency: ${sent.createdTimestamp - message.createdTimestamp}ms`);
    }
  }
}